# tests/Hola_mundo.py
print("Hola mundo!")